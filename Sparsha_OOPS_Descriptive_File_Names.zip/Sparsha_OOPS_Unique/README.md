# OOPS Lab Programs

Programs from both supplied ZIP collections, organized by topic.
Overlapping copies were consolidated; distinct exercises were retained.
Files explicitly identifying Kingson were excluded.
Each program starts with its heading, and filenames describe the program rather than using numbers.

## Program index

### Basic
- `5_largestnum.cpp`
- `6_string_length.cpp`
- `7_palindrome0.cpp`
- `Add_Two_Numbers.cpp`
- `Area_of_rec.cpp`
- `Calculate_Rectangle_Area.cpp`
- `Display_Personal_Information.cpp`
- `Display_Student_Details.cpp`
- `Max.cpp`
- `Swap_passbyref.cpp`
- `Swap_passbyvalue.cpp`
- `Swap_two_numbers_Pass_by_pointer.cpp`
- `Swap_two_numbers_Pass_by_reference.cpp`
- `Swap_two_numbers_by_value.cpp`

### Classes and Objects
- `3_scope_resolution.cpp`
- `4_rectangle.cpp`
- `Adding_two_complex_num.cpp`
- `Class_object.cpp`
- `Class_time_2objest.cpp`
- `Distance_parameter.cpp`
- `Passing_obj_arg.cpp`
- `Rec_class.cpp`
- `Student_Class_and_Object.cpp`

### Constructors and Destructors
- `2_cpp_defaualt_constructor.cpp`
- `Constructor.cpp`
- `Destructor_area.cpp`
- `Employee_Constructor_Initialization.cpp`
- `Employee_Parameterized_Constructor.cpp`
- `Mileage_constructor.cpp`
- `Paranmeter_cons.cpp`
- `Rectangle_Default_and_Parameterized_Constructors.cpp`
- `Type_cons.cpp`

### Exception Handling
- `Excep_divide.cpp`
- `Exception_handling.cpp`
- `Exceptionmultiplication.cpp`

### Inheritance
- `1_2.cpp`
- `1_3.cpp`
- `1_4.cpp`
- `2_2.cpp`
- `3_2.cpp`
- `3_3.cpp`
- `4_2.cpp`
- `4_3.cpp`
- `Abstract_Vehicle_Class.cpp`
- `Mul_inhere_student.cpp`
- `Multiple_inheretance_petrol.cpp`
- `P_30_single_inheritance.cpp`
- `Runtime_Polymorphism_Shape_Draw.cpp`
- `Shape_Circle_Function_Overriding.cpp`
- `Vehicle_and_Car_Inheritance.cpp`
- `Virtual_Function_Shape_Circle.cpp`

### Operator Overloading
- `Division_By_Zero_Exception.cpp`
- `Division_Exception_Handling.cpp`
- `Handle_Different_Exception_Types.cpp`
- `Handle_Integer_Exception.cpp`
- `Operatorz_subb.cpp`
- `String_Concatenation_Operator_Overloading.cpp`
- `Throw_and_Catch_Integer_Exception.cpp`

### Polymorphism
- `ComplexNumber_class_example.cpp`
- `Complex_Number_Addition_Operator.cpp`
- `Complex_Number_Subtraction_Operator.cpp`
- `Prefix_and_Postfix_Decrement_Operator.cpp`
- `Prefix_and_Postfix_Increment_Operator.cpp`

### Static and Friend
- `2_2.cpp`
- `Emp_static.cpp`
- `Friend_Function_Access_Two_Classes.cpp`
- `Friend_Function_Add_Class_Members.cpp`
- `Static_Data_Member_Employee_Count.cpp`
- `Static_data.cpp`
- `Static_data_members.cpp`
- `Static_function.cpp`

### Strings
- `6_time.cpp`
- `7_complex_number.cpp`
- `Emp_cons.cpp`
- `Len_of_string_style.cpp`
- `Length_of_string.cpp`
- `Pallin_using_stringstyle.cpp`
- `Pallindrome_char_array_str.cpp`
- `Student_Class_Set_and_Display_Data.cpp`
- `Student_Class_String_Input.cpp`
- `Time_subject_as_arguments.cpp`

**Total: 81 programs**

Compile an individual program with a C++ compiler, for example:
```bash
g++ Program.cpp -o Program
./Program
```
